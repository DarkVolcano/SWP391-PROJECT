﻿using Repositories;
using Repositories.DTO;
using Repositories.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public interface IScheduleServices
    {
        public List<ScheduleDTO> GetSchedule();
        public List<ScheduleDTO> GetSlotByCourtId(int CourtId);
        public ScheduleDTO GetScheduleById(int id);
        public void CreateSchedule(ScheduleDTO  scheduleDTO);
        public void UpdateSchedule(int id, ScheduleDTO scheduleDTO);
        public void DeleteSchedule(int id);
    }
    public class ScheduleServices : IScheduleServices
    {
        private readonly UnitOfWork _unitOfWork;

        public ScheduleServices()
        {
            _unitOfWork ??= new UnitOfWork();
        }
        public void CreateSchedule(ScheduleDTO scheduleDTO)
        {
            var schedule = new Schedule
            {
                ScheduleId = scheduleDTO.ScheduleId,
                CourtNumberId = scheduleDTO.CourtNumberId,
                SlotId = scheduleDTO.SlotId,
            };
            _unitOfWork.ScheduleRepo.Create(schedule);
            _unitOfWork.SaveChanges();
        }

        public void DeleteSchedule(int id)
        {
            var items = _unitOfWork.ScheduleRepo.GetById(id);
            if(items != null)
            {
                _unitOfWork.ScheduleRepo.Remove(items);
                _unitOfWork.SaveChanges();
            }
        }

        public List<ScheduleDTO> GetSlotByCourtId(int CourtId)
        {
            return _unitOfWork.ScheduleRepo.GetSlotByCourt(CourtId).Select(schedule => new ScheduleDTO
            {
                ScheduleId = schedule.ScheduleId,
                CourtNumberId = schedule.CourtNumberId,
                SlotId = schedule.SlotId,
            }).ToList();
        }
        public List<ScheduleDTO> GetSchedule()
        {
            return _unitOfWork.ScheduleRepo.GetAll().Select(schedule => new ScheduleDTO 
            { 
                ScheduleId = schedule.ScheduleId,
                CourtNumberId = schedule.CourtNumberId,
                SlotId = schedule.SlotId,
            }).ToList();
        }
        public ScheduleDTO GetScheduleById(int id)
        {
            var schedule = _unitOfWork.ScheduleRepo.GetById(id);
            return new ScheduleDTO
            {
                ScheduleId = schedule.ScheduleId,
                CourtNumberId = schedule.CourtNumberId,
                SlotId = schedule.SlotId,
            };
        }

        public void UpdateSchedule(int id, ScheduleDTO scheduleDTO)
        {
            var schedule = _unitOfWork.ScheduleRepo.GetById(id);
            schedule.CourtNumberId = scheduleDTO.CourtNumberId;
            schedule.SlotId = scheduleDTO.SlotId;
            _unitOfWork.ScheduleRepo.Update(schedule);
            _unitOfWork.SaveChanges();
        }
    }
}
