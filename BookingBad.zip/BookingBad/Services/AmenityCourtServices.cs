﻿using Repositories;
using Repositories.DTO;
using Repositories.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public interface IAmenityCourtServices
    {

        public List<AmenityCourtDTO> GetAmenityByCourtId(int idCourt);
        public void CreateAmenityCourt(AmenityCourtDTO amenityCourt, List<int> amenityIds);
        public void UpdateAmenityCourt(int idCourt, List<int> amenityIds);
        public void DeleteAmenityCourt(int idCourt);
    }
    public class AmenityCourtServices : IAmenityCourtServices
    {
        private readonly UnitOfWork _unitOfWork;

        public AmenityCourtServices()
        {
            _unitOfWork ??= new UnitOfWork();
        }
        public  List<AmenityCourtDTO> GetAmenityByCourtId(int idCourt)
        {
            return _unitOfWork.AmenityCountRepo.GetAmenityByCourtId(idCourt).
                Select(amenity => new AmenityCourtDTO 
                {   AmenityId = amenity.AmenityId, 
                    CourtId =amenity.CourtId,
                }).ToList();
        }
        public void CreateAmenityCourt(AmenityCourtDTO amenityCourtDTO, List<int> amenityIds)
        {
            foreach (var amenityId in amenityIds)
            {
                var newAmenityCourt = new AmenityCourt
                {
                    CourtId = amenityCourtDTO.CourtId,
                    AmenityId = amenityId
                };
                _unitOfWork.AmenityCountRepo.Create(newAmenityCourt);
            }
            _unitOfWork.SaveChanges();
        }
        public void DeleteAmenityCourt(int idCourt)
        {
            var courts = _unitOfWork.AmenityCountRepo.GetAmenityByCourtId(idCourt);
            foreach (var court in courts)
            {
               _unitOfWork.AmenityCountRepo.Remove(court);
               _unitOfWork.SaveChanges();
            }

        }
        public void UpdateAmenityCourt(int idCourt, List<int> amenityIds)
        {
            List<AmenityCourt> currentAmenities = _unitOfWork.AmenityCountRepo.GetAmenityByCourtId(idCourt);

            foreach (var amenity in currentAmenities)
            {
                _unitOfWork.AmenityCountRepo.Remove(amenity);
            }

            foreach (var amenityId in amenityIds)
            {
                var newAmenityCourt = new AmenityCourt
                {
                    CourtId = idCourt,
                    AmenityId = amenityId
                };
                _unitOfWork.AmenityCountRepo.Create(newAmenityCourt);
            }

            _unitOfWork.SaveChanges();
        }
    }
}
