﻿using Repositories;
using Repositories.DTO;
using Repositories.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    interface IAmenityServies
    {
        public List<AmenityDTO> GetAmenity();
        public AmenityDTO GetAmenityById(int id);
        public void CreateAmenity(AmenityDTO amenityDTO);
        public void UpdateAmenity(int id, AmenityDTO amenityDTO);
        public void DeleteAmeity(int id);
    }

    public class AmenityServices : IAmenityServies
    {
        private readonly UnitOfWork _unitOfWork;

        public AmenityServices()
        {
            _unitOfWork ??= new UnitOfWork();
        }

        public void CreateAmenity(AmenityDTO amenityDTO)
        {
            Amenity amenity = new Amenity
            {
                Description = amenityDTO.Description,
                Status = amenityDTO.Status,
            };   
            _unitOfWork.AmenityRepo.Create(amenity);
            _unitOfWork.SaveChanges();
        }

        public void DeleteAmeity(int id)
        {
            var items = _unitOfWork.AmenityRepo.GetById(id);
            if(items != null)
            {
                _unitOfWork.AmenityRepo.Remove(items);
                _unitOfWork.SaveChanges();
            }
        }

        public List<AmenityDTO> GetAmenity()
        {
            return _unitOfWork.AmenityRepo.GetAll().
                Select(amenity => new AmenityDTO
                {
                    AmenityId = amenity.AmenityId,
                    Description = amenity.Description,
                    Status = amenity.Status,
                }).ToList();
        }

        public AmenityDTO GetAmenityById(int id)
        {
            var amenity = _unitOfWork.AmenityRepo.GetById(id);
            return new AmenityDTO
            {
                AmenityId = amenity.AmenityId,
                Description = amenity.Description,
                Status = amenity.Status,
            };
        }

        public void UpdateAmenity(int id, AmenityDTO amenityDTO)
        {
            var amenity = _unitOfWork.AmenityRepo.GetById(id);
            if(amenity != null)
            {
                amenity.Description = amenityDTO.Description;
                amenity.Status = amenityDTO.Status;
                _unitOfWork.AmenityRepo.Update(amenity);
                _unitOfWork.SaveChanges();
            }
        }
    }
}
