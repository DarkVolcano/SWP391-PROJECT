﻿using Repositories;
using Repositories.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{

    public interface ICommentServices
    {
        public List<Comment> GetComment();
        public Comment GetCommentById(int id); 
        public void CreateComment(Comment comment);
        public void UpdateComment(int id, Comment comment);
        public void DeleteComment(int id);
    }
    public class CommentServices : ICommentServices
    {
        private readonly UnitOfWork _unitOfWork;

        public CommentServices()
        {
            _unitOfWork ??= new UnitOfWork();
        }
        public void CreateComment(Comment comment)
        {
            _unitOfWork.commentRepo.Create(comment);
            _unitOfWork.SaveChanges();
        }

        public void DeleteComment(int id)
        {
            var items = _unitOfWork.commentRepo.GetById(id);
            if(items != null)
            {
                _unitOfWork.commentRepo.Remove(items);
                _unitOfWork.SaveChanges();
            }
        }

        public List<Comment> GetComment()
        {
            return _unitOfWork.commentRepo.GetAll();
        }

        public Comment GetCommentById(int id)
        {
            return _unitOfWork.commentRepo.GetById(id);
        }

        public void UpdateComment(int id, Comment comment)
        {
            _unitOfWork.commentRepo.Update(id, comment);
            _unitOfWork.SaveChanges();
        }
    }
}
