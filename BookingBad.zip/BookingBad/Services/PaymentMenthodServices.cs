﻿using Repositories;
using Repositories.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public interface IPaymentMenthodServices
    {
        public List<PaymentMenthod> GetPaymentMenthod();
        public PaymentMenthod GetPaymentMenthodById(int id);
        public void CreatePaymentMenthod(PaymentMenthod paymentMenthod);
        public void UpdatePaymentMenthod(int id, PaymentMenthod paymentMenthod);
        public void DeletePaymentMenthod(int id);
    }
    public class PaymentMenthodServices : IPaymentMenthodServices
    {
        private readonly UnitOfWork _unitOfWork;

        public PaymentMenthodServices()
        {
            _unitOfWork ??= new UnitOfWork();
        }
        public void CreatePaymentMenthod(PaymentMenthod paymentMenthod)
        {
            _unitOfWork.PaymentMenthodRepo.Create(paymentMenthod);
            _unitOfWork.SaveChanges();
        }

        public void DeletePaymentMenthod(int id)
        {
            var items = _unitOfWork.PaymentMenthodRepo.GetById(id);
            if(items != null)
            {
                _unitOfWork.PaymentMenthodRepo.Remove(items);
                _unitOfWork.SaveChanges();
            }
        }

        public List<PaymentMenthod> GetPaymentMenthod()
        {
            return _unitOfWork.PaymentMenthodRepo.GetAll(); 
        }

        public PaymentMenthod GetPaymentMenthodById(int id)
        {
            return _unitOfWork.PaymentMenthodRepo.GetById(id);
        }

        public void UpdatePaymentMenthod(int id, PaymentMenthod paymentMenthod)
        {
            _unitOfWork.PaymentMenthodRepo.Update(id, paymentMenthod);
            _unitOfWork.SaveChanges();
        }
    }
}
