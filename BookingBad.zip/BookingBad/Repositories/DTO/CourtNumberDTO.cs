﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories.DTO
{
    public class CourtNumberDTO
    {
        public int CourtNumberId { get; set; }

        public string? Description { get; set; }

        public int? CourtId { get; set; }

    }
}
