﻿using Microsoft.EntityFrameworkCore;
using Repositories.DTO;
using Repositories.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories.Repositories
{
    public class AmenityCountRepo : GenericRepository<AmenityCourt>
    {
        public AmenityCountRepo() { }
        public List<AmenityCourt> GetAmenityByCourtId(int id)
        {
            return _dbSet.Where(c => c.CourtId == id)
                         .Include(c => c.Amenity)
                         .ToList();
        }
    }
}
