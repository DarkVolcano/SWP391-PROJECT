﻿using Repositories.Entities;
using System.Linq;

namespace Repositories.Repositories
{
    public class AccountRepo : GenericRepository<Account>
    {
        private readonly BookingBadmintonSystemContext _context;

        public AccountRepo(BookingBadmintonSystemContext context) : base(context)
        {
            _context = context;
        }

        public Account GetAccountByEmailAndPassword(string email, string password)
        {
            return _context.Accounts.FirstOrDefault(a => a.Email == email && a.Password == password);
        }
    }
}
